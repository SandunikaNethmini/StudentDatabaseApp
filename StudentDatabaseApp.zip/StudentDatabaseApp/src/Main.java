import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentDAO dao = new StudentDAO();

        while (true) {
            System.out.println("1. Add Student\n2. View Students\n3. Exit");
            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    System.out.print("Email: ");
                    String email = sc.nextLine();
                    System.out.print("Age: ");
                    int age = sc.nextInt();
                    dao.insertStudent(new Student(0, name, email, age));
                    break;
                case 2:
                    List<Student> students = dao.getAllStudents();
                    for (Student s : students) {
                        System.out.println(s.getId() + " | " + s.getName() + " | " + s.getEmail() + " | " + s.getAge());
                    }
                    break;
                case 3:
                    System.exit(0);
            }
        }
    }
}
